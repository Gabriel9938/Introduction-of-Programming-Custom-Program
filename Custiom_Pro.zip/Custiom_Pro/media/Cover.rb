
class Cover 
	attr_accessor :button
	
	def initialize
	@size = [660,460,20]
	@menu = ["Player 1","Ranking"]
	@button = Array.new(@menu.length)
	
	# @button = [[[14,7],[14,8],[15,7],[15,8],[16,7],[16,8],[17,7],[17,8],[18,7],[18,8]],
	# [[14,10],[14,11],[15,10],[15,11],[16,10],[16,11],[17,10],[17,11],[18,10],[18,11]]]
	end
	

	def mouse_over_cell(mouse_x, mouse_y)
    if mouse_x <= @size[2]
      cell_x = 0
    else
      cell_x = (mouse_x / @size[2]).to_i
    end

    if mouse_y <= @size[2]
      cell_y = 0
    else
      cell_y = (mouse_y / @size[2]).to_i
    end

    [cell_x, cell_y]
  end
	
	def draw
		Gosu.draw_rect(0, 0, @size[0], @size[1], Gosu::Color.argb(0xff_3399ff), ZOrder::BACKGROUND)
		if !@ramking_P
			w_move = 290
			h_move = 148
			x_cell = 7
			
			for a in 0..@menu.length-1
			y_cell = 14
			try1 = Array.new()
			for x in y_cell..y_cell+4
					for y in x_cell..x_cell + 1
					Gosu.draw_rect(x * @size[2], y.to_i * @size[2], @size[2], @size[2], Gosu::Color.argb(0xff_ffffff), ZOrder::MIDDLE)
					try1.push [x,y]
					end
				end
			Gosu::Font.new(25).draw_text("#{@menu[a]}",w_move, h_move, ZOrder::TOP, 1.0, 1.0, Gosu::Color::BLACK)
			@button << try1
			h_move+=60
			x_cell += 3
			end
		elsif @ramking_P
			x = 140
			y = 130
			for i in 0..@readrank.length
			Gosu::Font.new(30).draw_text("Player Ranking", 10, 10, ZOrder::TOP, 1.0, 1.0, Gosu::Color::WHITE)
			Gosu::Font.new(30).draw_text("Top #{i+1}.#{@readrank[i].uname}______#{@readrank[i].uscore}", x, y, ZOrder::TOP, 1.0, 1.0, Gosu::Color::WHITE)
				y+=70
			end
		end
	end
end

class Read_rank
	attr_accessor :date,:uscore
	def initialize(dat,score)
	@date = dat
	@uscore = score
	end

end