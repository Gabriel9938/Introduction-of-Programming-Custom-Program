
class Ball
	attr_accessor :score
	
	def initialize
	@Snake = Snake.new
	@score = 0
	@CELL_DIM = 20
	@win_width1 = 660 / @CELL_DIM
	@win_heigh1 = 460	/ @CELL_DIM
	@ball_x = rand(@win_width1)
	@ball_y = rand(@win_heigh1)
	@ball_xb = rand(@win_width1)
	@ball_yb = rand(@win_heigh1)
	
	end
	
	def draw
		Gosu.draw_rect(@ball_x.to_i * @CELL_DIM, @ball_y.to_i * @CELL_DIM, @CELL_DIM, @CELL_DIM, Gosu::Color.argb(0xff_FFFF00), ZOrder::MIDDLE)
		Gosu::Font.new(10).draw_text("Score: #{@score}", 10, 10, ZOrder::TOP, 2.0, 2.0, Gosu::Color.argb(0xff_00ac2c))
		if @score%10 == 0 and @score > 0
			Gosu.draw_rect(@ball_xb.to_i * @CELL_DIM, @ball_yb.to_i * @CELL_DIM, @CELL_DIM, @CELL_DIM, Gosu::Color.argb(0xff_FFFF00), ZOrder::MIDDLE)
		end
	end
	#normal ball
	def get_score (pos)
		if @ball_x == pos[0] and @ball_y == pos[1]
			@score += 1
			@ball_x = rand(@win_width1)
			@ball_y = rand(@win_heigh1)
			true
		end
	end
	#When the score % by 10 = 0 the bonues will show out
	def boneus(pos)
		if @ball_xb == pos[0] and @ball_yb == pos[1]
			@score += 4
			@ball_x = rand(@win_width1)
			@ball_y = rand(@win_heigh1)
			true
		end
	end
end