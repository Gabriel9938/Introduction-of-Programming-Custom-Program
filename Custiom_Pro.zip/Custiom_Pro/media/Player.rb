
class Snake
	attr_accessor :growing
	
	def initialize
		@S_positions = [[2,0],[2,1],[2,2],[2,3]] # Psition of the snake
		@direction = "down"
		@CELL_DIM = 20
		@win_width1 = 660 / @CELL_DIM
		@win_heigh1 = 460	/ @CELL_DIM
		@growing = 1
		@finish = false
	end
	#Control Snake
	def S_move_up
		if @direction != "down"
			@direction = "up"
		end
	end
	
	def S_move_down
		if @direction != "up"
			@direction = "down"
		end
	end
	
	def S_move_left
		if @direction != "right"
			@direction = "left"
		end
	end
	
	def S_move_right
		if @direction != "left"
			@direction = "right"
		end
	end
	#How the Snake will move
	def S_move
		if @growing != 0
			@S_positions.shift
		end	
		
		case @direction
			when "up"
				@S_positions.push(over(s_head[0], s_head[1] - 1))
			when "down"
				@S_positions.push(over(s_head[0], s_head[1] + 1))
			when "left"
				@S_positions.push(over(s_head[0] - 1, s_head[1]))
			when "right"
				@S_positions.push(over(s_head[0] + 1, s_head[1]))
		end
		@growing = 1
	end
	
	
	def over(x,y)
		[x%@win_width1,y%@win_heigh1]
	end
	
	
	#Display the snake
	def draw
	x = 0
		while x != @S_positions.length
			Gosu.draw_rect(@S_positions[x][0].to_i * @CELL_DIM, @S_positions[x][1].to_i * @CELL_DIM, @CELL_DIM-1, @CELL_DIM-1, Gosu::Color.argb(0xff_00ff00), ZOrder::MIDDLE)
			x += 1
		end
	end
	def head
		@S_positions
	end
	def s_head
		@S_positions.last
	end
	
	def grow
		@growing = 0
	end
	
	def eat_itself
		if @S_positions.uniq.length != @S_positions.length
			@finish = false
		else
			@finish = true
		end
	end

end