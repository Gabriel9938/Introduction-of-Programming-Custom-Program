require "gosu"
require "date"
require "./media/Cover"
require "./media/Player"
require "./media/Ball"


module ZOrder
  BACKGROUND, MIDDLE, TOP = *0..2
end

class Game_main_Window < Gosu::Window

	def initialize
		@size = [660,460,20]
		super @size[0],@size[1]
		self.caption ="Snake"
	
		@coverpage = true
		@ramking_P = false
		@c_arr = [Cover.new, Snake.new, Ball.new]
		@time = Time.now
		@speed = 0.1
		#read file
		ranking_file = File.new("media/Ranking.txt", "r")
		@readrank =  read_ranking(ranking_file)
		ranking_file.close()
		
	end
	
	def update
		#Player 1
			if Gosu.button_down? Gosu::KB_UP
				@c_arr[1].S_move_up
			elsif Gosu.button_down? Gosu::KB_DOWN
				@c_arr[1].S_move_down
			elsif Gosu.button_down? Gosu::KB_LEFT
				@c_arr[1].S_move_left
			elsif Gosu.button_down? Gosu::KB_RIGHT
				@c_arr[1].S_move_right
			end
		
		speed_up (@c_arr[2].score)#the speed of the snake will increase depent on the plsyer score
		
		unless !@c_arr[1].eat_itself
			return if Time.now - @time < @speed # to deley the update speed 
			@c_arr[1].S_move
			@time = Time.now
		end
		if @c_arr[2].get_score(@c_arr[1].s_head)
			@c_arr[1].grow
			Gosu::Sample.new("media/snakehit.wav").play
		elsif@c_arr[2].boneus(@c_arr[1].s_head)
			@c_arr[1].grow
			Gosu::Sample.new("media/snakehit.wav").play
		end
	end
	#call out the curser
	def needs_cursor?
		true
	end
	#read the record that store in the text file
	def read_ranking txtfile
		rank_num = txtfile.gets.chomp.to_i
		ranking = Array.new(rank_num)
		for i in 0..(rank_num-1)
			date = txtfile.gets.chomp
			score = txtfile.gets.chomp.to_i
			p_ranking = Read_rank.new(date, score)
			ranking[i] = p_ranking
		end	
		ranking
	end
	
	#update the top score when the user break the record
	def upate_ranking 
		score = @c_arr[2].score
		for i in 0..@readrank.length-1
			if @readrank[i].uscore <= score
				if i ==0
				@readrank[i+2].date = @readrank[i+1].date
				@readrank[i+2].uscore = @readrank[i+1].uscore
				@readrank[i+1].date = @readrank[i].date
				@readrank[i+1].uscore = @readrank[i].uscore
				elsif i == 1
				@readrank[i+1].date = @readrank[i].date
				@readrank[i+1].uscore = @readrank[i].uscore
				end
				@readrank[i].date = Date.today
				@readrank[i].uscore = score
			break
			end	
		end
		ranking_file = File.new("media/Ranking.txt", "w")
		ranking_file.puts @readrank.length
		for i in 0..@readrank.length-1
				ranking_file.puts @readrank[i].date
				ranking_file.puts @readrank[i].uscore
		end
		ranking_file.close()
	end
	
	#increase the update speed according to the player score
	def speed_up (score)
		case score
		when 10
			@speed = 0.09
		when 20
			@speed = 0.08
		when 30
			@speed = 0.07
		when 40
			@speed = 0.06
		when 50
			@speed = 0.03
		end
	end
	
	
	#Show out all the Images
	def draw
		col = @size[0] / @size[2]
		row = @size[1] / @size[2]
		for i in 0..col
			for x in 0..row
				Gosu.draw_rect(i * @size[2], x * @size[2], @size[2], @size[2], Gosu::Color.argb(0xff_006400), ZOrder::BACKGROUND)
			end
		end
		
		#show out the cover page
		if @coverpage and !@ramking_P
			@c_arr[0].draw
		elsif @ramking_P and @coverpage # show out the ranking page
			i = 0
			x = 150
			y = 130
			while i != @readrank.length
			Gosu::Font.new(30).draw_text("Player Ranking", 10, 10, ZOrder::TOP, 1.0, 1.0, Gosu::Color::WHITE)
			Gosu::Font.new(30).draw_text("Top #{i+1}.#{Date.today}__________#{@readrank[i].uscore}", x, y, ZOrder::TOP, 1.0, 1.0, Gosu::Color::WHITE)
				y+=70
				i+=1
			end
		else
			# as long as the snake does not eat itself the snake and ball will show out
			#but when the snake eat it self the game end
			unless !@c_arr[1].eat_itself
				@c_arr[1].draw
				@c_arr[2].draw
			else
				if @readrank[0].uscore <= @c_arr[2].score
					endgame = ["Game Over! Score was #{@c_arr[2].score}. New Record!!!","Press 'Enter' to save your record.","Press 'B' Back to menu.","Press 'R' to restart."]
				else
					endgame = ["Game Over! Score was #{@c_arr[2].score}.","Press 'Enter' to save your record.","Press 'B' Back to menu.","Press 'R' to restart."]
				end
				x = 10
				y = 10
				for i in 0..endgame.length-1
				Gosu::Font.new(20).draw_text("#{endgame[i]}", x, y, ZOrder::TOP, 1.0, 1.0, Gosu::Color::WHITE)
				y+=25
				end
			end
		end
	end
	
	def button_down(id)
		##--KB Input--##
		if id == Gosu::KB_ESCAPE #Quit Game
			close
		elsif id == Gosu::KB_R	#Restart Game
			print @c_arr[0].button
			@c_arr[1] = Snake.new
			@c_arr[2] = Ball.new
		elsif id == Gosu::KB_B	#Back to Menu Page
			@coverpage = true
			@ramking_P = false
			@c_arr[1] = Snake.new
			@c_arr[2] = Ball.new
		elsif id == Gosu::KB_RETURN or id == Gosu::KB_ENTER #To save the record of the player
			upate_ranking
			if @readrank[0].uscore <= @c_arr[2].score
				Gosu::Sample.new("media/crowd5.wav").play
			end
		else
			super
		end
		
		##--Mouse Input--##
		case id	
		when Gosu::MsLeft 
			cell = @c_arr[0].mouse_over_cell(mouse_x, mouse_y)# Start the Game
			if @c_arr[0].button[2].include? cell and !@ramking_P
				@coverpage = false
				Gosu::Sample.new("media/snakehiss2.wav").play
			elsif @c_arr[0].button[3].include? cell# View the Rank Page
				@ramking_P = true
			end
		
		end
	end
end


Game_main_Window.new.show